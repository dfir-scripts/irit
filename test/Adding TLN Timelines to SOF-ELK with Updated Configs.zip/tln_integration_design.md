# TLN Timeline Integration Architecture for SOF-ELK

## Overview

This document outlines the architecture for integrating TLN (Timeline) format files into the SOF-ELK platform. The integration follows SOF-ELK's modular configuration pattern and uses modern Elastic Stack features without deprecated configurations.

## Data Flow

The integration follows this pipeline:

```
TLN Files → Filebeat → Logstash → Elasticsearch → Kibana
```

### Step 1: File Collection (Filebeat)
Filebeat monitors directories containing TLN files and ships them to Logstash. The configuration uses the `filestream` input type (modern replacement for deprecated `log` input) and adds metadata tags to identify TLN data.

### Step 2: Parsing and Enrichment (Logstash)
Logstash receives the raw TLN lines and processes them through multiple stages:
- **Input**: Receives data from Beats on port 5044
- **Preprocessing**: Identifies TLN format based on tags
- **Parsing**: Splits pipe-delimited fields and converts epoch timestamp
- **Filtering**: Enriches data and normalizes fields
- **Output**: Sends to Elasticsearch with appropriate index pattern

### Step 3: Storage and Indexing (Elasticsearch)
Data is stored in Elasticsearch with a dedicated index pattern (`tln-*`) and custom field mappings optimized for timeline analysis.

### Step 4: Visualization (Kibana)
Users can query and visualize TLN timeline data through Kibana dashboards.

## Configuration File Structure

Following SOF-ELK's naming convention:

### Filebeat Configuration
- **File**: `filebeat-tln.yml`
- **Purpose**: Monitor TLN file directories and ship to Logstash
- **Location**: `/etc/filebeat/modules.d/` or custom configuration directory

### Logstash Configurations

1. **Input Configuration**: `0000-input-beats.conf` (already exists in SOF-ELK)
   - Receives data from Filebeat on port 5044
   - No modification needed

2. **Preprocessing Configuration**: `1100-preprocess-tln.conf`
   - Identifies TLN data based on tags/labels
   - Prepares data for main parsing

3. **Main Parsing Configuration**: `6100-tln.conf`
   - Parses pipe-delimited TLN format
   - Converts epoch timestamp to @timestamp
   - Extracts and normalizes fields
   - Handles optional semicolon-delimited description subfields

4. **Postprocessing Configuration**: `8100-postprocess-tln.conf`
   - Enriches data with additional context
   - Normalizes field values
   - Adds computed fields

5. **Output Configuration**: `9000-output-elastic-consolidated.conf` (already exists)
   - Sends to Elasticsearch
   - No modification needed

### Elasticsearch Configuration
- **Index Template**: `tln-template.json`
- **Index Pattern**: `tln-*`
- **Purpose**: Define field mappings and index settings

## Field Mapping Strategy

The TLN format fields are mapped to Elasticsearch fields as follows:

| TLN Field | Elasticsearch Field | Type | Description |
|-----------|-------------------|------|-------------|
| Time | @timestamp | date | Converted from Unix epoch to ISO8601 |
| Time | tln.time_epoch | long | Original epoch timestamp |
| Source | tln.source | keyword | Data source identifier |
| Host | tln.host | keyword | Host system identifier |
| User | tln.user | keyword | User identifier |
| Description | tln.description | text | Full description field |
| Description | tln.description.keyword | keyword | Non-analyzed version for aggregations |
| - | tln.description_parts | keyword array | Semicolon-separated parts if present |
| - | labels.type | keyword | Set to "tln" for identification |
| - | event.dataset | keyword | Set to "tln.timeline" |

## Processing Logic

### TLN Line Parsing
```
Input:  1123619888|EVT|PETER|S-1-5-18|Userenv/1517;EVENTLOG_WARNING_TYPE;PETER\Harlan
Output: 
  @timestamp: 2005-08-10T01:04:48.000Z
  tln.time_epoch: 1123619888
  tln.source: EVT
  tln.host: PETER
  tln.user: S-1-5-18
  tln.description: Userenv/1517;EVENTLOG_WARNING_TYPE;PETER\Harlan
  tln.description_parts: ["Userenv/1517", "EVENTLOG_WARNING_TYPE", "PETER\Harlan"]
  labels.type: tln
  event.dataset: tln.timeline
```

### Timestamp Handling
- Parse Unix epoch timestamp from first field
- Convert to ISO8601 format for @timestamp
- Preserve original epoch value in `tln.time_epoch`
- Handle both 32-bit and 64-bit epoch values
- Timezone: Assume UTC (as TLN format doesn't specify timezone)

### Description Field Processing
- Store full description in `tln.description`
- If description contains semicolons, split into `tln.description_parts` array
- Preserve original formatting and special characters

## Index Management

### Index Naming
- Pattern: `tln-YYYY.MM.DD`
- Example: `tln-2026.02.10`
- Allows for time-based index management and retention policies

### Index Settings
- Number of shards: 1 (adjust based on data volume)
- Number of replicas: 1 (adjust based on availability requirements)
- Refresh interval: 30s (balance between search performance and indexing speed)

## Tags and Labels

The integration uses tags and labels for data flow control:

- **Filebeat tags**: `["tln", "timeline", "forensics"]`
- **Filebeat fields**: `labels.type: "tln"`
- **Logstash processing tags**: Added/removed during pipeline stages
- **Error handling tags**: `["_grokparsefailure"]` for parsing errors

## Compatibility Considerations

### Modern Configuration Standards
- Use `ssl_enabled` instead of deprecated `ssl`
- Use `filestream` input instead of deprecated `log` input
- Use `labels.type` for data type identification (SOF-ELK standard)
- Avoid deprecated grok patterns
- Use modern field reference syntax

### SOF-ELK Integration
- Follow SOF-ELK numbering convention for configuration files
- Use existing input and output configurations
- Leverage SOF-ELK's grok pattern library
- Compatible with SOF-ELK's Kibana dashboards framework

## Error Handling

The pipeline includes error handling for common issues:

1. **Malformed TLN lines**: Lines that don't match the 5-field format are tagged with `_grokparsefailure`
2. **Invalid timestamps**: Epoch values that can't be converted are preserved as-is with error tag
3. **Empty fields**: Empty fields are preserved as null values
4. **Special characters**: Pipe characters within fields are not supported per TLN specification

## Performance Considerations

- **Filebeat**: Use `close_inactive` and `clean_inactive` to manage file handles
- **Logstash**: Grok parsing is optimized with anchored patterns
- **Elasticsearch**: Keyword fields for aggregations, text fields for full-text search
- **Bulk indexing**: Logstash batches events for efficient Elasticsearch ingestion
