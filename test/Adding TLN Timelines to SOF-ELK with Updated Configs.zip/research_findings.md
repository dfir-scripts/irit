# Research Findings: TLN Format and SOF-ELK Integration

## TLN Timeline Format Specification

### Format Structure
TLN is a 5-field pipe-delimited format created by Harlan Carvey:
```
Time|Source|Host|User|Description
```

### Field Definitions

1. **Time**: Unix epoch timestamp (seconds since Jan 1, 1970)
   - Originally 32-bit POSIX timestamp
   - Modern implementations support 64-bit values
   - Decimal numeric string format
   - No timezone information included

2. **Source**: Fixed-length field (~8 chars) for data source
   - Examples: file system, Registry, EVT/EVTX, AV logs, application logs
   - May require a key or legend
   - No standardized list of sources

3. **Host**: Host system identifier
   - Can be: IP address, MAC address, NetBIOS name, DNS name
   - May require a key or legend

4. **User**: User identifier
   - Can be: username, SID, email address, IM screenname
   - May require a key or legend

5. **Description**: Event description with context
   - Can be overloaded with semicolon-separated values
   - Example: `Userenv/1517;EVENTLOG_WARNING_TYPE;PETER\Harlan`
   - No predefined structure for sub-fields

### Example TLN Entry
```
1123619888|EVT|PETER|S-1-5-18|Userenv/1517;EVENTLOG_WARNING_TYPE;PETER\Harlan
```

### Known Limitations
- No timezone indication
- Second-only granularity (no sub-second precision)
- Pipe character (|) cannot be used within fields
- No standardized source type list

## SOF-ELK Architecture

### Overview
- **Creator**: Phil Hagen (SANS FOR572 course)
- **Purpose**: Big data analytics platform for forensics and security operations
- **Stack**: Elasticsearch + Logstash + Kibana + Filebeat
- **Repository**: https://github.com/philhagen/sof-elk

### Directory Structure
- `/configfiles/`: Logstash parsing/filtering configurations
- `/configfiles-templates/`: Template configurations
- `/grok-patterns/`: Custom grok patterns
- `/kibana/`: Dashboard definitions
- `/lib/`: Elasticsearch mappings, YAML lookups, supporting files
- `/supporting-scripts/`: Utility scripts

### Key Characteristics
- Pre-configured for multiple log types
- Uses Filebeat for log shipping
- Logstash for parsing and enrichment
- Elasticsearch for storage and search
- Kibana for visualization
- Modular configuration structure
