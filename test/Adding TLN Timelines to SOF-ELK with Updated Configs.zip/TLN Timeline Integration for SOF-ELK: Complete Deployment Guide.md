# TLN Timeline Integration for SOF-ELK: Complete Deployment Guide

**Author:** Manus AI  
**Date:** February 10, 2026  
**Version:** 1.1

---

## Introduction

This guide provides comprehensive instructions for integrating **TLN (Timeline) format** support, created by Harlan Carvey, into the **SOF-ELK (Security Operations and Forensics Elasticsearch, Logstash, Kibana)** platform developed by Phil Hagen. The TLN format is a widely used five-field, pipe-delimited timeline format in digital forensics, and this integration enables forensic analysts to ingest, parse, and visualize TLN timelines within the powerful SOF-ELK analytics environment.

The provided configuration files adhere to modern Elastic Stack best practices and avoid all deprecated configuration options. The integration is designed to be modular, non-disruptive to existing SOF-ELK configurations, and follows the established SOF-ELK file naming and organizational conventions.

---

## Understanding the TLN Format

The TLN format was introduced by Harlan Carvey and consists of five pipe-delimited fields. Each line in a TLN file represents a single timeline event with the following structure:

```
Time|Source|Host|User|Description
```

The fields are defined as follows:

| Field | Type | Description | Example |
|-------|------|-------------|---------|
| **Time** | Unix Epoch Timestamp | Number of seconds since January 1, 1970 (UTC) | `1123619888` |
| **Source** | Text (~8 chars) | Data source identifier (e.g., file system, Registry, EVT/EVTX) | `EVT` |
| **Host** | Text | Host system identifier (IP, MAC, NetBIOS, DNS name) | `PETER` |
| **User** | Text | User identifier (username, SID, email) | `S-1-5-18` |
| **Description** | Text | Event description; may contain semicolon-separated sub-fields | `Userenv/1517;EVENTLOG_WARNING_TYPE;PETER\Harlan` |

### Example TLN Entry

```
1123619888|EVT|PETER|S-1-5-18|Userenv/1517;EVENTLOG_WARNING_TYPE;PETER\Harlan
```

This entry represents an event that occurred on August 10, 2005, at 01:04:48 UTC, sourced from an Event Log (`EVT`) on host `PETER`, associated with user `S-1-5-18`, with a description containing multiple semicolon-separated components.

---

## Architecture Overview

The integration follows a standard Elastic Stack data pipeline architecture:

```
TLN Files → Filebeat → Logstash → Elasticsearch → Kibana
```

### Data Flow

**Filebeat** monitors directories containing TLN files and ships each line to Logstash. The modern `filestream` input type is used instead of the deprecated `log` input. Metadata tags identify the data as TLN format.

**Logstash** receives the raw TLN lines and processes them through multiple pipeline stages. The preprocessing stage identifies TLN data based on tags. The main parsing stage uses grok patterns to extract the five fields, converts the Unix epoch timestamp to ISO8601 format, and optionally splits the description field into sub-components if semicolons are present. The postprocessing stage adds enrichment fields.

**Elasticsearch** stores the parsed and enriched timeline data in a dedicated index pattern (`tln-*`) with optimized field mappings for timeline analysis.

**Kibana** provides visualization and analysis capabilities, allowing forensic analysts to query, filter, and visualize TLN timeline data alongside other forensic data sources already present in SOF-ELK.

---

## Configuration Files

The integration consists of four primary configuration files:

| File | Purpose | Location |
|------|---------|----------|
| `filebeat-tln.yml` | Filebeat input configuration | `/etc/filebeat/inputs.d/` |
| `1100-preprocess-tln.conf` | Logstash preprocessing | `/usr/local/sof-elk/configfiles/` |
| `7765-tln.conf` | Logstash main parsing | `/usr/local/sof-elk/configfiles/` |
| `tln-template.json` | Elasticsearch index template | Applied via API |

### File Naming Convention

The Logstash configuration files follow the SOF-ELK numeric prefix convention, which controls the order of pipeline processing:

- **0000-xxxx**: Input configurations
- **1000-xxxx**: Preprocessing configurations
- **6000-xxxx**: Main parsing and filtering configurations
- **7000-xxxx**: Additional parsing and filtering configurations
- **8000-xxxx**: Postprocessing configurations
- **9000-xxxx**: Output configurations

The TLN integration uses `1100-preprocess-tln.conf` for preprocessing and `7765-tln.conf` for main parsing, ensuring proper sequencing within the existing SOF-ELK pipeline.

---

## Detailed Configuration Breakdown

### Filebeat Configuration (`filebeat-tln.yml`)

This configuration uses the modern `filestream` input type to monitor directories for TLN files. The configuration is minimal and focused:

```yaml
- type: filestream
  id: tln-timeline-filestream
  enabled: true
  paths:
    - /logstash/tln/*.tln
    - /logstash/tln/**/*.tln
  fields:
    labels.type: tln
  fields_under_root: true
  tags: ["tln", "timeline", "forensics"]
```

**Key Features:**

- **`filestream` input type**: This is the modern replacement for the deprecated `log` input type, providing better performance and reliability.
- **Path patterns**: The configuration monitors both the `/logstash/tln/` directory and all subdirectories for files with the `.tln` extension.
- **`labels.type` field**: This field is set to `tln` and is used by SOF-ELK to identify the data type throughout the pipeline.
- **Tags**: Multiple tags are added for flexible filtering and identification in Logstash.

### Logstash Preprocessing Configuration (`1100-preprocess-tln.conf`)

This configuration identifies TLN data based on the `labels.type` field and adds a processing tag:

```
if [labels][type] == "tln" {
  mutate {
    add_tag => [ "tln_timeline" ]
  }
}
```

The `tln_timeline` tag is used in subsequent pipeline stages to route TLN data to the appropriate parsing logic.

### Logstash Main Parsing Configuration (`7765-tln.conf`)

This configuration performs the core parsing and transformation of TLN data:

```
if "tln_timeline" in [tags] {
  grok {
    match => { "message" => "%{NUMBER:tln.time_epoch}|%{DATA:tln.source}|%{DATA:tln.host}|%{DATA:tln.user}|%{GREEDYDATA:tln.description}" }
    add_tag => [ "tln_parsed" ]
  }

  if "_grokparsefailure" not in [tags] {
    date {
      match => [ "[tln][time_epoch]", "UNIX" ]
      timezone => "Etc/UTC"
    }

    if [tln][description] and [tln][description] =~ ";" {
      mutate {
        split => { "[tln][description]" => "tln.description_parts" }
        strip => "tln.description_parts"
      }
    }

    mutate {
      add_field => { "[event][dataset]" => "tln.timeline" }
    }
  } else {
    mutate {
      add_tag => [ "tln_parse_error" ]
    }
  }
}
```

**Key Processing Steps:**

1. **Grok Parsing**: The grok filter extracts the five pipe-delimited fields using pattern matching. The `NUMBER` pattern matches the epoch timestamp, `DATA` matches the source, host, and user fields, and `GREEDYDATA` captures the entire description field including any remaining content.

2. **Timestamp Conversion**: The `date` filter converts the Unix epoch timestamp to ISO8601 format and sets it as the event's `@timestamp` field. The timezone is explicitly set to UTC, as the TLN format does not include timezone information.

3. **Description Field Splitting**: If the description field contains semicolons, it is split into an array called `tln.description_parts`, allowing for easier analysis of structured description data.

4. **Event Dataset Field**: The `event.dataset` field is set to `tln.timeline` for consistency with Elastic Common Schema (ECS) conventions.

5. **Error Handling**: If the grok pattern fails to match, the event is tagged with `tln_parse_error` for troubleshooting.

### Elasticsearch Index Template (`tln-template.json`)

The index template defines the field mappings and index settings for TLN data:

```json
{
  "index_patterns": ["tln-*"],
  "template": {
    "settings": {
      "number_of_shards": 1,
      "number_of_replicas": 1
    },
    "mappings": {
      "properties": {
        "@timestamp": { "type": "date" },
        "tln": {
          "properties": {
            "time_epoch": { "type": "long" },
            "source": { "type": "keyword" },
            "host": { "type": "keyword" },
            "user": { "type": "keyword" },
            "description": {
              "type": "text",
              "fields": {
                "keyword": { "type": "keyword", "ignore_above": 256 }
              }
            },
            "description_parts": { "type": "keyword" }
          }
        },
        "labels": {
          "properties": {
            "type": { "type": "keyword" }
          }
        },
        "event": {
          "properties": {
            "dataset": { "type": "keyword" }
          }
        }
      }
    }
  }
}
```

**Field Mapping Strategy:**

- **`@timestamp`**: Standard date field for time-based queries and visualizations.
- **`tln.time_epoch`**: Preserves the original Unix epoch timestamp as a long integer.
- **`tln.source`, `tln.host`, `tln.user`**: Keyword fields optimized for exact matching, aggregations, and filtering.
- **`tln.description`**: Multi-field mapping with both `text` (for full-text search) and `keyword` (for aggregations) sub-fields.
- **`tln.description_parts`**: Keyword array for structured description components.

---

## Deployment Instructions

### Prerequisites

Before deploying the TLN integration, ensure the following:

- SOF-ELK VM is installed and running.
- Filebeat and Logstash services are operational.
- You have root or sudo access to the SOF-ELK system.
- Elasticsearch is accessible on `localhost:9200`.

### Step 1: Deploy Filebeat Configuration

Copy the `filebeat-tln.yml` file to the Filebeat inputs directory:

```bash
sudo cp filebeat-tln.yml /etc/filebeat/inputs.d/tln.yml
```

Verify the configuration syntax:

```bash
sudo filebeat test config -c /etc/filebeat/filebeat.yml
```

### Step 2: Deploy Logstash Configurations

Copy the Logstash configuration files to `/usr/local/sof-elk/configfiles/` and create symbolic links in `/etc/logstash/conf.d/`.

```bash
# Copy files to the SOF-ELK configfiles directory
sudo cp 1100-preprocess-tln.conf /usr/local/sof-elk/configfiles/1100-preprocess-tln.conf
sudo cp 7765-tln.conf /usr/local/sof-elk/configfiles/7765-tln.conf

# Create symbolic links in the Logstash conf.d directory
sudo ln -s /usr/local/sof-elk/configfiles/1100-preprocess-tln.conf /etc/logstash/conf.d/1100-preprocess-tln.conf
sudo ln -s /usr/local/sof-elk/configfiles/7765-tln.conf /etc/logstash/conf.d/7765-tln.conf
```

Set appropriate file permissions:

```bash
sudo chown logstash:logstash /usr/local/sof-elk/configfiles/1100-preprocess-tln.conf
sudo chown logstash:logstash /usr/local/sof-elk/configfiles/7765-tln.conf
sudo chmod 644 /usr/local/sof-elk/configfiles/1100-preprocess-tln.conf
sudo chmod 644 /usr/local/sof-elk/configfiles/7765-tln.conf
```

Verify the Logstash configuration syntax:

```bash
sudo /usr/share/logstash/bin/logstash --config.test_and_exit -f /etc/logstash/conf.d/
```

### Step 3: Deploy Elasticsearch Index Template

Install the Elasticsearch index template using the `curl` command:

```bash
curl -X PUT "http://localhost:9200/_index_template/tln_template" \
  -H "Content-Type: application/json" \
  -d @tln-template.json
```

Verify the template was installed successfully:

```bash
curl -X GET "http://localhost:9200/_index_template/tln_template"
```

### Step 4: Create TLN Data Directory

Create the directory where TLN files will be placed for ingestion:

```bash
sudo mkdir -p /logstash/tln
sudo chown elk_user:elk_user /logstash/tln
sudo chmod 755 /logstash/tln
```

Replace `elk_user` with the appropriate user account on your SOF-ELK system.

### Step 5: Restart Services

Restart the Filebeat and Logstash services to apply the new configurations:

```bash
sudo systemctl restart filebeat
sudo systemctl restart logstash
```

Verify the services are running:

```bash
sudo systemctl status filebeat
sudo systemctl status logstash
```

---

## Testing the Integration

To verify the integration is working correctly, create a sample TLN file and monitor the data flow through the pipeline.

### Create Sample TLN File

Create a file named `sample.tln` with the following content:

```
1123619888|EVT|PETER|S-1-5-18|Userenv/1517;EVENTLOG_WARNING_TYPE;PETER\Harlan
1644492800|REG|WORKSTATION1|jdoe|HKCU\Software\Microsoft\Windows\CurrentVersion\Run|OneDrive
1609459200|FS|SERVER01|admin|C:\Windows\System32\config\SAM modified
1577836800|NET|192.168.1.100|SYSTEM|Connection established to 10.0.0.50:443
```

Place the file in the monitored directory:

```bash
sudo cp sample.tln /logstash/tln/
```

### Verify Data Ingestion

After a few moments (typically 30-60 seconds), the data should be indexed in Elasticsearch. You can verify this by querying the index:

```bash
curl -X GET "http://localhost:9200/tln-*/_search?pretty" -H "Content-Type: application/json" -d 
{
  "query": { "match_all": {} },
  "size": 10
}
```

### Create Kibana Index Pattern

Open Kibana in your web browser and create a new index pattern:

1. Navigate to **Management** → **Stack Management** → **Index Patterns**.
2. Click **Create index pattern**.
3. Enter `tln-*` as the index pattern.
4. Select `@timestamp` as the time field.
5. Click **Create index pattern**.

### Explore Data in Kibana

Navigate to **Discover** and select the `tln-*` index pattern. You should see the ingested TLN timeline events with all parsed fields available for filtering and analysis.

---

## Field Reference

The following table describes all fields created by the TLN integration:

| Field | Type | Description |
|-------|------|-------------|
| `@timestamp` | date | Event timestamp in ISO8601 format (converted from epoch) |
| `tln.time_epoch` | long | Original Unix epoch timestamp from TLN file |
| `tln.source` | keyword | Data source identifier (e.g., EVT, REG, FS) |
| `tln.host` | keyword | Host system identifier |
| `tln.user` | keyword | User identifier |
| `tln.description` | text | Full event description (analyzed for full-text search) |
| `tln.description.keyword` | keyword | Non-analyzed version for aggregations |
| `tln.description_parts` | keyword array | Semicolon-separated description components |
| `labels.type` | keyword | Data type identifier (set to "tln") |
| `event.dataset` | keyword | Event dataset identifier (set to "tln.timeline") |
| `tags` | keyword array | Processing tags (e.g., "tln", "timeline", "forensics") |

---

## Troubleshooting

### Data Not Appearing in Elasticsearch

If data is not appearing in Elasticsearch after placing TLN files in the monitored directory, check the following:

**Filebeat Status**: Verify Filebeat is running and monitoring the correct paths:

```bash
sudo systemctl status filebeat
sudo journalctl -u filebeat -f
```

**Logstash Status**: Check Logstash logs for parsing errors:

```bash
sudo journalctl -u logstash -f
```

**File Permissions**: Ensure Filebeat has read access to the TLN files:

```bash
ls -la /logstash/tln/
```

### Parsing Errors

If events are tagged with `_grokparsefailure` or `tln_parse_error`, the TLN file may contain malformed lines. Common issues include:

- Lines with fewer or more than five pipe-delimited fields.
- Non-numeric values in the timestamp field.
- Special characters that interfere with parsing.

You can query for parsing errors in Kibana:

```
tags: "_grokparsefailure" OR tags: "tln_parse_error"
```

### Performance Issues

If ingestion is slow or Logstash is consuming excessive resources:

- **Increase Logstash heap size**: Edit `/etc/logstash/jvm.options` and adjust `-Xms` and `-Xmx` values.
- **Adjust pipeline workers**: Edit `/etc/logstash/logstash.yml` and set `pipeline.workers` to match the number of CPU cores.
- **Optimize grok patterns**: The provided grok pattern is already optimized, but ensure no other conflicting patterns are running.

---

## Customization

### Changing TLN File Locations

To monitor different directories for TLN files, edit the `paths` section in `/etc/filebeat/inputs.d/tln.yml`:

```yaml
paths:
  - /path/to/your/tln/files/*.tln
  - /another/path/**/*.tln
```

Restart Filebeat after making changes:

```bash
sudo systemctl restart filebeat
```

### Adjusting Index Settings

To change the number of shards or replicas, edit the `tln-template.json` file before deployment:

```json
"settings": {
  "number_of_shards": 2,
  "number_of_replicas": 0
}
```

Reapply the template after making changes:

```bash
curl -X PUT "http://localhost:9200/_index_template/tln_template" \
  -H "Content-Type: application/json" \
  -d @tln-template.json
```

### Adding Custom Enrichment

You can add additional enrichment logic to the Logstash configuration. For example, to add GeoIP enrichment for IP addresses in the `tln.host` field, add the following to `7765-tln.conf`:

```
if [tln][host] =~ /^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$/ {
  geoip {
    source => "[tln][host]"
    target => "[tln][geo]"
  }
}
```

---

## Compatibility Notes

### Elastic Stack Versions

The provided configurations are compatible with Elastic Stack versions 8.x and 9.x. They avoid all deprecated configuration options as of Logstash 9.0 and Filebeat 9.0.

### SOF-ELK Versions

The configurations follow SOF-ELK's established patterns and should be compatible with recent SOF-ELK releases. The modular design ensures that the TLN integration does not interfere with existing SOF-ELK functionality.

### Modern Configuration Standards

The configurations adhere to modern Elastic Stack best practices:

- Use of `filestream` input instead of deprecated `log` input in Filebeat.
- Use of `ssl_enabled` instead of deprecated `ssl` in SSL configurations (not applicable to this integration but noted for completeness).
- Use of `labels.type` for data type identification, consistent with SOF-ELK conventions.
- Avoidance of deprecated grok patterns and field reference syntax.

---

## Conclusion

This integration provides a robust, production-ready solution for ingesting and analyzing TLN timeline data within the SOF-ELK platform. The modular configuration design ensures compatibility with existing SOF-ELK workflows while providing the flexibility to customize and extend the integration as needed. By following the deployment instructions and best practices outlined in this guide, forensic analysts can seamlessly incorporate TLN timelines into their investigative workflows.

---

## References

- Harlan Carvey's TLN Format Specification: [Forensics Wiki - TLN](https://forensics.wiki/tln/)
- SOF-ELK GitHub Repository: [philhagen/sof-elk](https://github.com/philhagen/sof-elk)
- Elastic Stack Documentation: [Elastic Docs](https://www.elastic.co/docs)
- Logstash Breaking Changes: [Logstash 9.0 Breaking Changes](https://www.elastic.co/docs/release-notes/logstash/breaking-changes)
