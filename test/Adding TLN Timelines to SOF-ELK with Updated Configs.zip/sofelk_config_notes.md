# SOF-ELK Configuration Patterns

## File Naming Convention
Configuration files use numeric prefixes to control processing order:
- `0000-xxxx`: Input configurations
- `1000-xxxx`: Preprocessing configurations
- `6000-xxxx`: Main parsing/filtering configurations
- `8000-xxxx`: Postprocessing configurations
- `9000-xxxx`: Output configurations

## Example Input Configuration (0000-input-beats.conf)
```
input {
  # live beats protocol via tcp port
  # assign [labels][type] on the shipper!
  beats {
    port => 5044
    tags => [ "process_archive", "filebeat" ]
  }
}
```

## Key Observations
1. SOF-ELK uses Beats (Filebeat) as primary input method
2. Uses `labels.type` field for data type identification
3. Tags are used for processing control
4. Modular configuration with clear separation of concerns
5. Numbering scheme ensures proper pipeline order

## Configuration Directory Structure
- Input files: 0000-0099
- Preprocessing: 1000-1999
- Main processing: 6000-6999
- Postprocessing: 8000-8999
- Output: 9000-9999
