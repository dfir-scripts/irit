# Deprecated Features and Modern Configuration Requirements

## Logstash 9.0+ Breaking Changes

### SSL Settings Changes
Old deprecated SSL settings have been replaced with standardized ones:
- `ssl` → `ssl_enabled`
- `ssl_verify_mode` → `ssl_client_authentication`
- `cipher_suites` → `ssl_cipher_suites`
- `tls_min_version` / `tls_max_version` → `ssl_supported_protocols`
- `ca_file` / `cacert` → `ssl_certificate_authorities`
- `ssl_cert` → `ssl_certificate`
- `keystore` → `ssl_keystore_path`
- `keystore_password` → `ssl_keystore_password`

### Other Important Changes
1. **Pipeline buffer type**: Now defaults to `heap` (was `direct`)
2. **Logstash modules removed**: Framework deprecated, use Elastic Integrations
3. **Configuration settings**: 
   - `http.*` settings replaced with `api.*`
   - `event_api.tags.illegal` removed
4. **JDK requirement**: Minimum JDK17 (JDK11 no longer supported)
5. **Superuser**: Cannot run as superuser by default (set `allow_superuser: true` to override)
6. **Internal monitoring**: Requires `xpack.monitoring.allow_legacy_collection: true`

## Modern Configuration Best Practices

### Input Plugins
- Use `beats` input for Filebeat integration
- Use `ssl_enabled` instead of deprecated `ssl`
- Use `ssl_client_authentication` instead of `ssl_verify_mode`

### Filter Plugins
- Avoid deprecated grok patterns
- Use modern field references with bracket notation
- Use `labels.type` for data type identification

### Output Plugins
- Use `ssl_enabled` instead of `ssl`
- Use `ssl_certificate_authorities` instead of `cacert`
- Use `ssl_verification_mode` instead of `ssl_certificate_verification`

## Filebeat Best Practices
- Use `filestream` input type (replaces deprecated `log` input)
- Configure proper multiline handling
- Set appropriate harvester limits
- Use fields for metadata tagging
